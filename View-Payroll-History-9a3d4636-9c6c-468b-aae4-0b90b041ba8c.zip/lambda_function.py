import json
import boto3
from boto3.dynamodb.conditions import Key

def lambda_handler(event, context):
    # Initialize DynamoDB client
    dynamodb = boto3.resource('dynamodb')

    # Replace 'PayrollTable' with your DynamoDB table name
    table = dynamodb.Table('PayrollTable')

    # Example: Fetching all payroll history for a specific employee
    # Assume employee_id is passed in the query string parameters
    employee_id = event.get('queryStringParameters', {}).get('employee_id')

    if not employee_id:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Missing employee_id in query parameters'})
        }

    try:
        # Query DynamoDB to get payroll data for the employee
        response = table.query(
            KeyConditionExpression=Key('employee_id').eq(employee_id)
        )

        # Format the response data
        payroll_history = response.get('Items', [])

        # Return data as JSON
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'  # Update with your domain if needed
            },
            'body': json.dumps({'payroll_history': payroll_history})
        }

    except Exception as e:
        print(f"Error fetching payroll history: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': 'Internal Server Error'})
        }
