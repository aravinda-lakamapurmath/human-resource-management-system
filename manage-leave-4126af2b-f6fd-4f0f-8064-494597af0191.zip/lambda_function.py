import json
import boto3
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')

# Replace 'LeaveRequests' with your DynamoDB table name
table_name = 'LeaveRequests'
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        http_method = event['httpMethod']
        query_params = event.get('queryStringParameters', {})
        
        if http_method == 'GET' and 'request_id' in query_params:
            return handle_get_request(query_params['request_id'])
        elif http_method == 'POST' and 'action' in query_params and 'request_id' in query_params:
            return handle_post_request(query_params['request_id'], query_params['action'])
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Invalid request'})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Internal server error', 'error': str(e)})
        }

def handle_get_request(request_id):
    response = table.query(
        KeyConditionExpression=Key('request_id').eq(request_id)
    )
    
    if 'Items' not in response or len(response['Items']) == 0:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': 'Request not found'})
        }

    return {
        'statusCode': 200,
        'body': json.dumps(response['Items'][0])
    }

def handle_post_request(request_id, action):
    if action not in ['approve', 'reject']:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Invalid action'})
        }

    # Fetch the existing item to check its status
    response = table.get_item(Key={'request_id': request_id})
    
    if 'Item' not in response:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': 'Request not found'})
        }

    leave_request = response['Item']

    if leave_request['status'] != 'Pending':
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Request already processed'})
        }

    # Update the item status
    new_status = 'Approved' if action == 'approve' else 'Rejected'

    table.update_item(
        Key={'request_id': request_id},
        UpdateExpression='SET #st = :s',
        ExpressionAttributeNames={'#st': 'status'},
        ExpressionAttributeValues={':s': new_status}
    )

    return {
        'statusCode': 200,
        'body': json.dumps({'message': f'Request {action}ed successfully'})
    }
