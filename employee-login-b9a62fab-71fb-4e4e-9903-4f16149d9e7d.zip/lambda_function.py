import json
import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

dynamodb = boto3.resource('dynamodb')

# Replace 'LoginTable' with your DynamoDB table name
table_name = 'LoginTable'

# Ensure your DynamoDB table has 'username' as the partition key
try:
    table = dynamodb.Table(table_name)
except (NoCredentialsError, PartialCredentialsError):
    raise Exception("AWS credentials not configured or incomplete.")

def lambda_handler(event, context):
    try:
        # Parse the HTTP method and request body
        http_method = event.get('httpMethod', '')
        body = json.loads(event.get('body', '{}'))

        if http_method == 'POST':
            action = body.get('action')  # "hr_login" or "employee_login"

            if action not in ["hr_login", "employee_login"]:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': 'Invalid action provided'})
                }

            username = body.get('username')
            password = body.get('password')

            if not username or not password:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': 'Username and password are required'})
                }

            # Fetch the user from DynamoDB
            response = table.get_item(Key={'username': username})
            user = response.get('Item')

            if not user or user['password'] != password or user['role'] != action:
                return {
                    'statusCode': 401,
                    'body': json.dumps({'message': 'Invalid credentials or role'})
                }

            return {
                'statusCode': 200,
                'body': json.dumps({'message': f'Welcome {username}', 'role': user['role']})
            }

        return {
            'statusCode': 405,
            'body': json.dumps({'message': 'Method not allowed'})
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Internal Server Error', 'error': str(e)})
        }
