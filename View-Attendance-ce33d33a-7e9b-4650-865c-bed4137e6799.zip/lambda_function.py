import json

def lambda_handler(event, context):
    # Example attendance data (could be passed in the event)
    attendance_data = [
        {"date": "2024-12-01", "status": "Present", "in_time": "9:00 AM", "out_time": "6:00 PM"},
        {"date": "2024-12-02", "status": "Absent", "in_time": "N/A", "out_time": "N/A"},
        {"date": "2024-12-03", "status": "Present", "in_time": "9:15 AM", "out_time": "6:10 PM"}
    ]
    
    # Processing the data to return in a suitable format
    processed_data = []
    
    for record in attendance_data:
        processed_data.append({
            "Date": record["date"],
            "Status": record["status"],
            "In Time": record["in_time"],
            "Out Time": record["out_time"]
        })
    
    # Return the processed attendance data as a response
    return {
        'statusCode': 200,
        'body': json.dumps(processed_data)
    }

