import json

def lambda_handler(event, context):
    # Get request body from the event (form data sent by POST)
    body = json.loads(event['body'])
    
    # Extract username and password from the form data
    username = body.get('username')
    password = body.get('password')
    
    # Example hardcoded credentials (you can replace this with a real database check)
    correct_username = "admin"
    correct_password = "password123"
    
    # Validate credentials
    if username == correct_username and password == correct_password:
        # Return successful login response
        response = {
            "statusCode": 200,
            "body": json.dumps({"message": "Login successful!"})
        }
    else:
        # Return invalid login response
        response = {
            "statusCode": 401,
            "body": json.dumps({"message": "Invalid username or password"})
        }
    
    return response
