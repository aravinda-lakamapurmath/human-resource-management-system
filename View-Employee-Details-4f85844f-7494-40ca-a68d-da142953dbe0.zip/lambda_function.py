import json
import boto3
from botocore.exceptions import ClientError

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table_name = 'EmployeeDetails'  # Replace with your table name
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    """
    Lambda function to fetch employee details from DynamoDB.
    
    Args:
        event (dict): The API Gateway event, including query parameters.
        context (LambdaContext): The runtime information of the Lambda function.

    Returns:
        dict: HTTP response with employee details or error message.
    """
    # Extract employee_id from query parameters
    employee_id = event.get('queryStringParameters', {}).get('employee_id')

    if not employee_id:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Employee ID is required."})
        }

    try:
        # Fetch employee details from DynamoDB
        response = table.get_item(Key={'employee_id': employee_id})

        if 'Item' not in response:
            return {
                "statusCode": 404,
                "body": json.dumps({"error": "Employee not found."})
            }

        employee = response['Item']
        
        # Prepare the response
        return {
            "statusCode": 200,
            "body": json.dumps({
                "employee": {
                    "first_name": employee.get('first_name', 'N/A'),
                    "last_name": employee.get('last_name', 'N/A'),
                    "email": employee.get('email', 'N/A'),
                    "position": employee.get('position', 'N/A'),
                    "department": employee.get('department', 'N/A'),
                    "status": employee.get('status', 'N/A'),
                    "join_date": employee.get('join_date', 'N/A'),
                }
            })
        }

    except ClientError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Internal server error: {e.response['Error']['Message']}"})
        }
