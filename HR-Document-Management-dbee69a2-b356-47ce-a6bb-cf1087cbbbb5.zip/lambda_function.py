import json
import boto3
import os
import uuid
from datetime import datetime

# Initialize S3 client
s3_client = boto3.client('s3')
bucket_name = os.environ['S3_BUCKET_NAME']  # Set the bucket name in environment variables

def upload_document(event, context):
    try:
        # Parse the form data from the event object
        body = json.loads(event['body'])
        document_name = body['document-name']
        document_file = body['document-file']

        # Create a unique ID for the file to avoid name collisions
        unique_file_name = f"{uuid.uuid4().hex}-{document_file['filename']}"

        # Upload the file to S3
        s3_client.put_object(
            Bucket=bucket_name,
            Key=unique_file_name,
            Body=document_file['file'],
            ContentType=document_file['mimetype']
        )

        # Save the document details in a database (DynamoDB can be used)
        # For simplicity, we can print this part, but ideally you should save it to DynamoDB
        document_data = {
            'document_name': document_name,
            's3_key': unique_file_name,
            'upload_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        print("Document uploaded:", document_data)

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Document uploaded successfully'})
        }

    except Exception as e:
        print("Error uploading document:", e)
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Failed to upload document', 'error': str(e)})
        }


def get_documents(event, context):
    try:
        # List objects from S3 to retrieve document details
        response = s3_client.list_objects_v2(Bucket=bucket_name)
        
        documents = []
        for obj in response.get('Contents', []):
            document = {
                'document_name': obj['Key'],
                'upload_date': obj['LastModified'].strftime('%Y-%m-%d %H:%M:%S'),
                'url': f"https://{bucket_name}.s3.amazonaws.com/{obj['Key']}"
            }
            documents.append(document)

        return {
            'statusCode': 200,
            'body': json.dumps({'documents': documents})
        }

    except Exception as e:
        print("Error fetching documents:", e)
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Failed to fetch documents', 'error': str(e)})
        }


def lambda_handler(event, context):
    if event['httpMethod'] == 'POST' and event['resource'] == '/upload':
        return upload_document(event, context)
    elif event['httpMethod'] == 'GET' and event['resource'] == '/documents':
        return get_documents(event, context)
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Invalid request'})
        }
