import boto3
import json
import uuid

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Employees')

def lambda_handler(event, context):
    # Parse the incoming request body
    body = json.loads(event['body'])
    employee_id = str(uuid.uuid4())

    # Prepare the item to be inserted into the DynamoDB table
    item = {
        'FirstName': body['FirstName'],
        'LastName': body['LastName'],
        'Email': body['Email'],
        'Position': body['Position'],
        'Department': body['Department'],
        'Select Status': body.get('Active', 'Inactive')  # Default to 'Active' if not provided
    }

    # Insert the item into the DynamoDB table
    table.put_item(Item=item)

    # Return a success response
    return {
        'statusCode': 201,
        'body': json.dumps({'message': 'Employee added', 'EmployeeID': employee_id})
    }
