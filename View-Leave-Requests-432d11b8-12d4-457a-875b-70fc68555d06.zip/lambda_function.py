import json
import boto3
from boto3.dynamodb.conditions import Key

def lambda_handler(event, context):
    # Initialize the DynamoDB client
    dynamodb = boto3.resource('dynamodb')

    # Table name
    table_name = 'LeaveStatus'
    
    # Access the table
    table = dynamodb.Table(table_name)

    try:
        # Query the table to fetch all leave records (you can customize this query based on user ID or other parameters)
        response = table.scan()

        # Extract items from the response
        leave_records = response.get('Items', [])

        # Format the data for the frontend
        formatted_records = [
            {
                "leave_type": record.get("LeaveType", "Unknown"),
                "start_date": record.get("StartDate", "Unknown"),
                "end_date": record.get("EndDate", "Unknown"),
                "status": record.get("Status", "Unknown"),
                "reason": record.get("Reason", "Unknown"),
            }
            for record in leave_records
        ]

        # Return the formatted data as a JSON response
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'  # Enable CORS for frontend
            },
            'body': json.dumps(formatted_records)
        }

    except Exception as e:
        # Handle any exceptions that occur
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({"error": str(e)})
        }
