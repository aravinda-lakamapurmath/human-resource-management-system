import json
import boto3
from datetime import datetime
import uuid

# Initialize DynamoDB or RDS connection
dynamodb = boto3.resource('dynamodb')
leave_table = dynamodb.Table('leave_requests')  # Replace with your table name

def lambda_handler(event, context):
    body = json.loads(event['body'])
    
    leave_request = {
        'leave_type': body['leave_type'],
        'start_date': body['start_date'],
        'end_date': body['end_date'],
        'reason': body.get('reason', ''),
    }
    
    # Save the leave request to the database
    leave_table.put_item(Item=leave_request)
    
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Leave request submitted successfully!', 'request_id': leave_request['request_id']})
    }
