
import json
import boto3
import base64
import os
import uuid

# Initialize AWS clients
s3_client = boto3.client('s3')
dynamodb_client = boto3.resource('dynamodb')

# Define environment variables
S3_BUCKET_NAME = os.environ['S3_BUCKET_NAME']  # Set this in the Lambda environment variables
DYNAMODB_TABLE_NAME = os.environ['DYNAMODB_TABLE_NAME']  # Set this in the Lambda environment variables

def lambda_handler(event, context):
    try:
        # Parse form data from the event
        body = json.loads(event['body'])

        expense_name = body['expense-name']
        expense_amount = float(body['expense-amount'])
        expense_description = body['expense-description']
        receipt_file_data = body['expense-receipt']  # Base64 encoded file data
        
        # Generate unique IDs for the receipt file and the record
        receipt_file_name = f"receipt_{uuid.uuid4()}.png"  # Adjust extension based on file type
        expense_id = str(uuid.uuid4())

        # Upload receipt to S3
        file_data = base64.b64decode(receipt_file_data)
        s3_client.put_object(Bucket=S3_BUCKET_NAME, Key=receipt_file_name, Body=file_data)

        # Save expense details to DynamoDB
        table = dynamodb_client.Table(DYNAMODB_TABLE_NAME)
        table.put_item(
            Item={
                'ExpenseId': expense_id,
                'ExpenseName': expense_name,
                'ExpenseAmount': expense_amount,
                'ExpenseDescription': expense_description,
                'ReceiptFileName': receipt_file_name
            }
        )

        # Return a success response
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'message': 'Expense claim submitted successfully!'})
        }
    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'error': 'Failed to process expense claim.'})
        }