import json

def lambda_handler(event, context):
    # Check HTTP method
    method = event['httpMethod']
    path = event['resource']
    
    # Define response structure
    response = {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps("Success")
    }

    # Handle different endpoints
    if path == "/add_employee" and method == "POST":
        # Code to add employee
        response['body'] = json.dumps({"message": "Employee added successfully!"})
    
    elif path == "/view_employee_details" and method == "GET":
        # Code to view employee details
        employee_id = event["queryStringParameters"].get("employee_id")
        if employee_id:
            # Fetch employee details from DB or data source
            response['body'] = json.dumps({"employee_id": employee_id, "name": "John Doe", "position": "Software Engineer"})
        else:
            response['body'] = json.dumps({"error": "Employee ID not provided"})

    elif path == "/edit_employee_details" and method == "PUT":
        # Code to edit employee details
        employee_data = json.loads(event['body'])
        if 'employee_id' in employee_data and 'name' in employee_data:
            response['body'] = json.dumps({"message": f"Employee {employee_data['name']} details updated successfully!"})
        else:
            response['body'] = json.dumps({"error": "Employee data missing"})

    elif path == "/list_all_employees" and method == "GET":
        # Code to list all employees
        # Fetch employee list from DB or data source
        employees = [{"employee_id": 1, "name": "John Doe", "position": "Software Engineer"}, 
                     {"employee_id": 2, "name": "Jane Smith", "position": "HR Manager"}]
        response['body'] = json.dumps({"employees": employees})

    elif path == "/manage_leave_requests" and method == "GET":
        # Code to manage leave requests
        response['body'] = json.dumps({"message": "Leave requests management page."})

    elif path == "/payroll_management" and method == "GET":
        # Code for payroll management
        response['body'] = json.dumps({"message": "Payroll management page."})

    elif path == "/performance_reviews" and method == "GET":
        # Code for performance reviews
        response['body'] = json.dumps({"message": "Performance reviews management page."})

    elif path == "/hr_document_management" and method == "GET":
        # Code for document management
        response['body'] = json.dumps({"message": "HR document management page."})

    elif path == "/expense_claims_review" and method == "GET":
        # Code for expense claims review
        response['body'] = json.dumps({"message": "Expense claims review page."})

    else:
        # Handle invalid routes
        response['statusCode'] = 404
        response['body'] = json.dumps({"error": "Endpoint not found"})

    return response
