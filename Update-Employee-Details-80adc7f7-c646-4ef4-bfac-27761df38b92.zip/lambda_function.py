import json
import re

def lambda_handler(event, context):
    try:
        # Parse the body of the request (assuming it is a POST request with form data)
        body = json.loads(event.get('body', '{}'))
        
        # Validate the required fields
        required_fields = ['first_name', 'last_name', 'email', 'position', 'department', 'status']
        for field in required_fields:
            if field not in body:
                return generate_response(400, f"Missing required field: {field}")
        
        # Extract form data
        first_name = body['first_name']
        last_name = body['last_name']
        email = body['email']
        position = body['position']
        department = body['department']
        status = body['status']
        
        # Validate email format
        if not is_valid_email(email):
            return generate_response(400, "Invalid email format.")
        
        # Assuming we have a function to update employee details in a database
        updated_employee = update_employee_details(
            first_name, last_name, email, position, department, status
        )
        
        # Prepare the response
        return generate_response(200, "Employee details updated successfully!", updated_employee)
    
    except Exception as e:
        return generate_response(500, f"Error updating employee details: {str(e)}")

def update_employee_details(first_name, last_name, email, position, department, status):
    # This function would interact with your database to update employee details
    # Replace this with actual database update logic
    return {
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "position": position,
        "department": department,
        "status": status
    }

def is_valid_email(email):
    # Simple regex to check if the email format is valid
    email_regex = r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
    return re.match(email_regex, email) is not None

def generate_response(status_code, message, employee=None):
    # Helper function to generate a consistent API response
    response_body = {"message": message}
    if employee:
        response_body["employee"] = employee
    
    return {
        "statusCode": status_code,
        "body": json.dumps(response_body)
    }
