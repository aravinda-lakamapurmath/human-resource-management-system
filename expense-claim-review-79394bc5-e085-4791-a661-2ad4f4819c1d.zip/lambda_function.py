import json
import boto3
from botocore.exceptions import ClientError

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ExpenseClaims')

def get_expense_claims(event, context):
    """Fetch all pending expense claims."""
    try:
        # Scan the DynamoDB table to get all the claims with 'Pending' status
        response = table.scan(
            FilterExpression="Status = :status",
            ExpressionAttributeValues={
                ":status": "Pending"
            }
        )
        claims = response.get('Items', [])
        
        # Return the response as a JSON object
        return {
            'statusCode': 200,
            'body': json.dumps(claims)
        }
    
    except ClientError as e:
        print(e.response['Error']['Message'])
        return {
            'statusCode': 500,
            'body': json.dumps({"message": "Error fetching claims"})
        }

def update_expense_status(event, context):
    """Approve or Reject expense claim based on provided status."""
    try:
        # Get data from the request
        claim_id = event['pathParameters']['claim_id']
        action = event['queryStringParameters']['action']
        
        if action not in ['approve', 'reject']:
            return {
                'statusCode': 400,
                'body': json.dumps({"message": "Invalid action. Use 'approve' or 'reject'"})
            }

        # Define the new status based on the action
        new_status = 'Approved' if action == 'approve' else 'Rejected'

        # Update the DynamoDB table with the new status
        response = table.update_item(
            Key={'ClaimID': claim_id},
            UpdateExpression="set #st = :s",
            ExpressionAttributeNames={'#st': 'Status'},
            ExpressionAttributeValues={':s': new_status},
            ReturnValues="UPDATED_NEW"
        )
        
        # Return success response
        return {
            'statusCode': 200,
            'body': json.dumps({"message": f"Claim {claim_id} has been {new_status}"})
        }
    
    except ClientError as e:
        print(e.response['Error']['Message'])
        return {
            'statusCode': 500,
            'body': json.dumps({"message": "Error updating claim status"})
        }

def lambda_handler(event, context):
    """Main Lambda handler to route requests."""
    if event['httpMethod'] == 'GET':
        return get_expense_claims(event, context)
    
    if event['httpMethod'] == 'POST' and 'claim_id' in event['pathParameters']:
        return update_expense_status(event, context)

    return {
        'statusCode': 400,
        'body': json.dumps({"message": "Invalid request"})
    }
