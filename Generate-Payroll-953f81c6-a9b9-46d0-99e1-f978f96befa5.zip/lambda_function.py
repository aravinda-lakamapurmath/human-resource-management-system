import json
import boto3
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
payroll_table = dynamodb.Table('PayrollTable')  # Replace with your DynamoDB table name

def decimal_to_float(obj):
    if isinstance(obj, list):
        return [decimal_to_float(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: decimal_to_float(v) for k, v in obj.items()}
    elif isinstance(obj, Decimal):
        return float(obj)
    return obj

def lambda_handler(event, context):
    http_method = event['httpMethod']
    path = event['path']
    query_params = event.get('queryStringParameters', {})

    if path == "/api/hr/view-payroll" and http_method == "GET":
        return view_payroll(query_params)

    if path == "/api/hr/edit-payroll" and http_method == "POST":
        return edit_payroll(event)

    if path == "/api/hr/process-payroll" and http_method == "POST":
        return process_payroll(query_params)

    return {
        'statusCode': 404,
        'body': json.dumps({"message": "Endpoint not found"})
    }

def view_payroll(query_params):
    employee_id = query_params.get('employee_id')

    if not employee_id:
        return {
            'statusCode': 400,
            'body': json.dumps({"message": "employee_id is required"})
        }

    try:
        response = payroll_table.get_item(Key={'employee_id': employee_id})
        item = response.get('Item')

        if not item:
            return {
                'statusCode': 404,
                'body': json.dumps({"message": "Employee not found"})
            }

        return {
            'statusCode': 200,
            'body': json.dumps(decimal_to_float(item))
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({"message": "Error fetching payroll data", "error": str(e)})
        }

def edit_payroll(event):
    try:
        payload = json.loads(event['body'])
        employee_id = payload.get('employee_id')

        if not employee_id:
            return {
                'statusCode': 400,
                'body': json.dumps({"message": "employee_id is required"})
            }

        payroll_table.update_item(
            Key={'employee_id': employee_id},
            UpdateExpression="SET salary = :salary, bonus = :bonus, tax_deductions = :tax_deductions, net_pay = :net_pay",
            ExpressionAttributeValues={
                ':salary': Decimal(payload['salary']),
                ':bonus': Decimal(payload['bonus']),
                ':tax_deductions': Decimal(payload['tax_deductions']),
                ':net_pay': Decimal(payload['net_pay'])
            }
        )

        return {
            'statusCode': 200,
            'body': json.dumps({"message": "Payroll data updated successfully"})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({"message": "Error updating payroll data", "error": str(e)})
        }

def process_payroll(query_params):
    employee_id = query_params.get('employee_id')

    if not employee_id:
        return {
            'statusCode': 400,
            'body': json.dumps({"message": "employee_id is required"})
        }

    try:
        response = payroll_table.get_item(Key={'employee_id': employee_id})
        item = response.get('Item')

        if not item:
            return {
                'statusCode': 404,
                'body': json.dumps({"message": "Employee not found"})
            }

        # Example: mark payroll as processed
        payroll_table.update_item(
            Key={'employee_id': employee_id},
            UpdateExpression="SET processed = :processed",
            ExpressionAttributeValues={':processed': True}
        )

        return {
            'statusCode': 200,
            'body': json.dumps({"message": "Payroll processed successfully"})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({"message": "Error processing payroll", "error": str(e)})
        }
