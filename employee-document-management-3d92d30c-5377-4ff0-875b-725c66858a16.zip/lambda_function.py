import json
import boto3
import os
from urllib.parse import unquote_plus
from datetime import datetime

s3_client = boto3.client('s3')
BUCKET_NAME = os.environ['BUCKET_NAME']

def lambda_handler(event, context):
    # Get HTTP method and path from API Gateway event
    method = event['httpMethod']
    path = event['path']
    
    if method == 'POST' and path == '/upload':
        return upload_file(event)
    elif method == 'GET' and path == '/files':
        return get_uploaded_files()
    elif method == 'GET' and path.startswith('/files/'):
        return download_file(path)
    elif method == 'DELETE' and path.startswith('/files/'):
        return delete_file(path)
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Invalid request'})
        }

def upload_file(event):
    """Handles file upload"""
    try:
        body = json.loads(event['body'])
        file_content = body['file']
        file_name = body['fileName']
        
        # Upload to S3
        s3_client.put_object(Bucket=BUCKET_NAME, Key=file_name, Body=file_content)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'File uploaded successfully'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f'Error uploading file: {str(e)}'})
        }

def get_uploaded_files():
    """Fetches the list of uploaded files from S3"""
    try:
        response = s3_client.list_objects_v2(Bucket=BUCKET_NAME)
        files = []
        for obj in response.get('Contents', []):
            files.append({
                'fileName': obj['Key'],
                'uploadDate': obj['LastModified'].strftime('%Y-%m-%d')
            })
        
        return {
            'statusCode': 200,
            'body': json.dumps({'files': files})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f'Error fetching files: {str(e)}'})
        }

def download_file(path):
    """Handles file download"""
    try:
        file_name = unquote_plus(path.split('/')[-1])
        file_obj = s3_client.get_object(Bucket=BUCKET_NAME, Key=file_name)
        
        return {
            'statusCode': 200,
            'body': file_obj['Body'].read(),
            'headers': {
                'Content-Type': file_obj['ContentType'],
                'Content-Disposition': f'attachment; filename={file_name}'
            }
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f'Error downloading file: {str(e)}'})
        }

def delete_file(path):
    """Handles file deletion"""
    try:
        file_name = unquote_plus(path.split('/')[-1])
        s3_client.delete_object(Bucket=BUCKET_NAME, Key=file_name)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': f'File {file_name} deleted successfully'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f'Error deleting file: {str(e)}'})
        }
