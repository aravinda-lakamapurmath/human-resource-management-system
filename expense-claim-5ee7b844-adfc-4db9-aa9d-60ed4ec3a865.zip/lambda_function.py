import json

def lambda_handler(event, context):
    # Example data for expense claims (this could be fetched from a database or another source)
    expense_claims = [
        {
            "Claim ID": "EC-1001",
            "Expense Name": "Travel",
            "Amount": "$150.00",
            "Status": "Approved",
            "Date Submitted": "2024-12-05"
        },
        {
            "Claim ID": "EC-1002",
            "Expense Name": "Meals",
            "Amount": "$50.00",
            "Status": "Pending",
            "Date Submitted": "2024-12-10"
        },
        {
            "Claim ID": "EC-1003",
            "Expense Name": "Supplies",
            "Amount": "$200.00",
            "Status": "Rejected",
            "Date Submitted": "2024-12-12"
        }
    ]
    
    # Preparing the response
    response = {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps(expense_claims)
    }
    
    return response
