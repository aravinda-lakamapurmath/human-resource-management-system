import json
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table_name = "PerformanceReviews"  # Replace with your DynamoDB table name
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        if event['httpMethod'] == 'POST':
            return handle_post(event)
        elif event['httpMethod'] == 'GET':
            return handle_get(event)
        else:
            return {
                'statusCode': 405,
                'body': json.dumps({'message': 'Method not allowed'})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def handle_post(event):
    data = json.loads(event['body'])

    required_fields = ['employee-id', 'employee-name', 'review-date', 'performance-rating', 'comments']
    for field in required_fields:
        if field not in data:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': f'Missing field: {field}'})
            }

    review = {
        'EmployeeID': data['employee-id'],
        'EmployeeName': data['employee-name'],
        'ReviewDate': data['review-date'],
        'PerformanceRating': data['performance-rating'],
        'Comments': data['comments'],
        'Timestamp': datetime.utcnow().isoformat()
    }

    table.put_item(Item=review)

    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Performance review submitted successfully!'})
    }

def handle_get(event):
    employee_id = event['queryStringParameters'].get('employee-id') if event['queryStringParameters'] else None

    if employee_id:
        response = table.get_item(Key={'EmployeeID': employee_id})
        if 'Item' in response:
            return {
                'statusCode': 200,
                'body': json.dumps(response['Item'])
            }
        else:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'Review not found'})
            }
    else:
        response = table.scan()
        return {
            'statusCode': 200,
            'body': json.dumps(response['Items'])
        }