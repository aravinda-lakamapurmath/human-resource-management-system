import json
import boto3
import os

# Initialize DynamoDB client or any database connection you need
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['EMPLOYEE_TABLE'])  # Dynamically fetch table name from environment variables

def lambda_handler(event, context):
    try:
        # Fetching employee data from DynamoDB (or another data source)
        response = table.scan()  # Scan operation can be replaced with Query if needed for optimization
        employees = response['Items']
        
        # Process the employee data and format it
        employee_list = []
        for employee in employees:
            employee_data = {
                'EmployeeID': employee.get('EmployeeID'),
                'Name': employee.get('Name'),
                'Email': employee.get('Email'),
                'Position': employee.get('Position'),
                'Department': employee.get('Department'),
                'Status': employee.get('Status')
            }
            employee_list.append(employee_data)
        
        # Return the response as JSON to the frontend
        return {
            'statusCode': 200,
            'body': json.dumps({
                'status': 'success',
                'employees': employee_list
            }),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
    
    except Exception as e:
        # Handle errors and return an error message
        return {
            'statusCode': 500,
            'body': json.dumps({
                'status': 'error',
                'message': str(e)
            }),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
