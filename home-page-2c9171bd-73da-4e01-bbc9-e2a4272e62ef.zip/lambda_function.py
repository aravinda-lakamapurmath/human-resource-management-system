import json

def lambda_handler(event, context):
    # Check if the request is a POST for login (you can modify this to suit your needs)
    if event['httpMethod'] == 'POST':
        body = json.loads(event['body'])
        username = body.get('username')
        password = body.get('password')
        
        # Here you can add your logic to validate username and password
        # For demonstration, we'll assume a simple hardcoded check
        
        if username == 'admin' and password == 'password123':
            response = {
                "statusCode": 200,
                "body": json.dumps({
                    "message": "Login successful",
                    "status": "success"
                }),
                "headers": {
                    "Content-Type": "application/json"
                }
            }
        else:
            response = {
                "statusCode": 401,
                "body": json.dumps({
                    "message": "Invalid credentials",
                    "status": "error"
                }),
                "headers": {
                    "Content-Type": "application/json"
                }
            }
        return response

    # If it's not a POST request, return a 400 error
    return {
        "statusCode": 400,
        "body": json.dumps({"message": "Bad Request"}),
        "headers": {
            "Content-Type": "application/json"
        }
    }
